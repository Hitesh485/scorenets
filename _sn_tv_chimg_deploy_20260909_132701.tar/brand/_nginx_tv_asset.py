#!/usr/bin/env python3
"""Insert nginx location so /api/v1/asset/ proxies to img.sofascore.com (TV channel logos).

Must sit BEFORE the general /api/v1/ → :18471 block. Leaves JSON relay untouched.
"""
from pathlib import Path

p = Path("/etc/nginx/sites-enabled/scorenets.com")
t = p.read_text(encoding="utf-8", errors="replace")

MARKER = "    # ScoreNet: TV/asset images via Sofascore img CDN"
if MARKER in t:
    print("nginx asset location already present")
else:
    block = (
        MARKER
        + "\n"
        + "    location ^~ /api/v1/asset/ {\n"
        + "        proxy_pass https://img.sofascore.com;\n"
        + "        proxy_http_version 1.1;\n"
        + "        proxy_ssl_server_name on;\n"
        + "        proxy_set_header Host img.sofascore.com;\n"
        + "        proxy_set_header Accept image/*,*/*;\n"
        + "        proxy_set_header Referer https://www.sofascore.com/;\n"
        + "        proxy_set_header User-Agent Mozilla/5.0;\n"
        + "        proxy_hide_header Set-Cookie;\n"
        + "        proxy_ignore_headers Set-Cookie;\n"
        + "        add_header Cache-Control \"public, max-age=86400\" always;\n"
        + "        add_header Access-Control-Allow-Origin * always;\n"
        + "        proxy_read_timeout 30s;\n"
        + "    }\n"
        + "\n"
    )
    anchor = "    # Live Sofascore JSON"
    idx = t.find(anchor)
    if idx < 0:
        idx = t.find("    location /api/v1/ {")
    if idx < 0:
        raise SystemExit("cannot find /api/v1/ block to insert before")
    t = t[:idx] + block + t[idx:]
    p.write_text(t, encoding="utf-8")
    print("nginx asset location inserted")

# sanity
t2 = p.read_text(encoding="utf-8", errors="replace")
assert "location ^~ /api/v1/asset/" in t2
assert "proxy_pass https://img.sofascore.com" in t2
assert "127.0.0.1:18471" in t2
print("nginx asset ok; 18471 still present")
