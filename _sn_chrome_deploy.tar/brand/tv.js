/* ScoreNet header — Download app chip (replaces Live TV) */
(function () {
  var VER = "20260907chrome";
  var APP_HREF =
    "https://app.sofascore.com/?utm_source=scorenet&utm_medium=web&utm_campaign=download_app";

  function isBadMount(el) {
    if (!el || !el.closest) return true;
    if (el.id === "header-ad-container" || el.closest("#header-ad-container")) return true;
    if (el.closest('[data-aaad],[id*="gpt-ad"],[class*="ad-unit"]')) return true;
    var cls = String(el.className || "");
    if (/\bw_\[30px\]\b/.test(cls) && /\bh_\[30px\]\b/.test(cls)) return true;
    return false;
  }

  function isDownloadAnchor(a) {
    if (!a || a.tagName !== "A") return false;
    if (a.getAttribute("data-sn-download-app") === "1") return true;
    if (a.id === "sn-download-app-link") return true;
    var href = a.getAttribute("href") || "";
    var txt = (a.textContent || "").replace(/\s+/g, " ").trim();
    return /download app/i.test(txt) || /app\.sofascore\.com/i.test(href) || /deep_link_value/i.test(href);
  }

  function findMobileRightCluster(header) {
    var download = Array.prototype.find.call(header.querySelectorAll("a"), isDownloadAnchor);
    if (download && download.parentElement && !isBadMount(download.parentElement)) {
      return download.parentElement;
    }
    var bars = header.querySelectorAll("div");
    for (var i = 0; i < bars.length; i++) {
      var el = bars[i];
      var cls = String(el.className || "");
      if (cls.indexOf("jc_space-between") >= 0 && cls.indexOf("h_[48px]") >= 0) {
        var kids = el.children;
        if (kids && kids.length) {
          var right = kids[kids.length - 1];
          if (right && !isBadMount(right)) return right;
        }
      }
    }
    return null;
  }

  function findDesktopMount(header) {
    var nav =
      header.querySelector("nav") ||
      header.querySelector('[class*="Navigation"]') ||
      null;
    if (nav && !isBadMount(nav)) return nav;
    return null;
  }

  function removeLiveTv() {
    try {
      document.querySelectorAll("#sn-live-tv-link, a[data-sn-tv='1']").forEach(function (n) {
        if (n && n.parentNode) n.parentNode.removeChild(n);
      });
    } catch (e) {}
  }

  function styleDownload(a) {
    a.id = "sn-download-app-link";
    a.setAttribute("data-sn-download-app", "1");
    a.removeAttribute("data-sn-tv");
    a.textContent = "Download app";
    a.setAttribute("href", APP_HREF);
    a.setAttribute("target", "_blank");
    a.setAttribute("rel", "noopener noreferrer");
    a.setAttribute("aria-label", "Download app");
  }

  function ensureDownloadApp() {
    try {
      removeLiveTv();
      var header =
        document.querySelector("header") ||
        document.querySelector('[class*="Header"]');
      if (!header) return;

      // Prefer native Sofascore download link if present
      var native = Array.prototype.find.call(header.querySelectorAll("a"), function (a) {
        if (a.getAttribute("data-sn-download-app") === "1" && a.id === "sn-download-app-link") {
          return false; // our inject — handle below
        }
        var href = a.getAttribute("href") || "";
        var txt = (a.textContent || "").replace(/\s+/g, " ").trim();
        return /download app/i.test(txt) || /app\.sofascore\.com/i.test(href) || /deep_link_value/i.test(href);
      });
      if (native) {
        document.querySelectorAll("#sn-download-app-link").forEach(function (n) {
          if (n !== native && n.parentNode) n.parentNode.removeChild(n);
        });
        styleDownload(native);
        return;
      }

      var existing = document.getElementById("sn-download-app-link");
      var mount =
        window.matchMedia("(max-width: 899px)").matches
          ? findMobileRightCluster(header)
          : findDesktopMount(header) || findMobileRightCluster(header);

      if (!mount || isBadMount(mount)) mount = findMobileRightCluster(header);
      if (!mount || isBadMount(mount)) return;

      if (existing) {
        styleDownload(existing);
        if (existing.parentElement !== mount) {
          existing.parentElement && existing.parentElement.removeChild(existing);
          // insert below
        } else {
          return;
        }
      } else {
        existing = document.createElement("a");
        styleDownload(existing);
      }

      var before = null;
      var children = mount.children;
      for (var i = children.length - 1; i >= 0; i--) {
        var c = children[i];
        if (
          c.classList &&
          (c.classList.contains("sn-header-ql-btn") || c.getAttribute("data-sn-ql-injected") === "1")
        ) {
          before = c;
          break;
        }
        if (c.tagName === "BUTTON" || (c.tagName === "A" && !(c.textContent || "").trim())) {
          before = c;
          break;
        }
      }
      if (before) mount.insertBefore(existing, before);
      else mount.appendChild(existing);
    } catch (e) {}
  }

  ensureDownloadApp();
  document.addEventListener("DOMContentLoaded", ensureDownloadApp);
  setInterval(ensureDownloadApp, 2000);
})();
